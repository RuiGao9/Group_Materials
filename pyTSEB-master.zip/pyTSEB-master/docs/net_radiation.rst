net_radiation package
=====================

.. automodule:: pyTSEB.net_radiation
    :members:
    :undoc-members:
    :show-inheritance:
